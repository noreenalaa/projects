/***********************************************************
 * COP 4530
 * Fatemah Elsewaky
 * Noreen Abdelmaksoud
 * April 6, 2023
 * 
 * This is the cpp file for the decision tree. It contains 
 * the main function as well as all other classes, strcuts, and functions that are necessary for this program to function and run
 * 
 * ********************************************************/

#include <iostream>
#include <algorithm>
#include <climits>
#include <cctype>
#include <fstream>
#include <sstream>
#include <string>
#include <vector>
#include <cmath>
#include <stack>

using namespace std;

struct treeInfo {
    int nodeLevel;       //variable to represent the level / height of the node in the tree
    int nodeIndex;      //variable to represent the number of the node in the level
    string nodeEdge;     //variable to hold the label that belongs to the parent edge
    string nodeContent;  //variable to hold the content / info of the node
    
    treeInfo(int level, int index, string edge, string content) {
        nodeLevel = level;         //set the 'nodeLevel' member variable of the object to the value of 'level'
        nodeIndex = index;       //set the 'nodeIndex' member variable of the object to the value of 'index'
        nodeEdge = edge;           //set the 'nodeEdge' member variable of the object to the value of 'edge'
        nodeContent = content;     //set the 'nodeContent' member variable of the object to the value of 'content'
    }
};

template <typename T>
class Node {
public:
    T node_data = { 0, 0, "", "" };                    //declare a node variable with set values
    vector<Node<T>*> child_nodes;                  //vector that contains pointers that point to the child nodes

    Node(T data) {                                 //constructor that takes data and initializes a node_data that stores said data
        node_data = data;
    }

    //copy constructor
    Node(const Node& other) {                   //copy constructor to declare a copy of any node that is given
        node_data = other.node_data;                    //set the node_data equal to the data of the other node 

        //duplicate each child of the current node and append the copies to its children vector
        int m = 0;
        while (m < other.child_nodes.size()) {
            Node<T>* child = other.child_nodes[m];
            child_nodes.push_back(new Node<T>(*child));
            m++;
        }
    }
};


template <typename T>
class LinkedList {
  private:
      Node<T>* root;                              //pointer to the tree's root node
  
      void deleteNodes(Node<T>* node) {                //private function to recursively delete every node in the tree 
          int i = 0;
          while (i < node->children.size()) {
              deleteNodes(node->children[i]);              //recursively deletes any children of the current node 
              i++;
          }
          delete node;                                     //delete the current node
      }
  
      void printNodes(Node<T>* node, int level) {       //private function that recursively prints the tree 
          if (node == nullptr) {                           //if the current node is null, exit through the usage of return;
              return;
          }
  
          int i = 0;
          while (i < level) {                //print spaces that are directly proportional to the height of the node
              cout << "  ";
              i++;
          }
  
          cout << "- " << node->myData << endl;              //print the info of the current node along with a hyphen
  
          i = 0;
          while (i < node->children.size()) {
              printNodes(node->children[i], level + 1);     //call the printNodes() function recursively for each child of the current node
              i++;
          }
      }
  public:
      LinkedList(T data) {                        //constructor that takes the data associated with the root and initializes the tree with the root node
          root = new Node<T>(data);
      }
  
      ~LinkedList() {                                 //destructor to free up memory through deleting all nodes
          //recursively delete all nodes 
          deleteNodes(root);
      }
  
      void add(Node<T>* parent_node, T child_data) {   //function that adds a child node to any given parent node
        Node<T>* child_node = new Node<T>(child_data); //creates a new child node with the given data
        parent_node->child_nodes.push_back(child_node);   //add the child node to the parent node's children vector
    }
      void printTree() {                                  //function to print the tree by calling the function printNodes()
          printNodes(root, 0);                            //call the printNodes() function with the root node and a starting level of 0
      }
};

void printPreOrderTree(Node<treeInfo>* current, ofstream& newFile, int level = 0) {
    //print the appropriate number of hyphens to symbolize the height of the current node
    for (int i = 0; i < level; i++) {
        newFile << "--";
    }

    //print the edge as well as content of the current node
    if (current->node_data.nodeLevel == 0) {
        newFile << current->node_data.nodeContent << endl;
    } else {
        newFile << "[" << current->node_data.nodeEdge << "] " << current->node_data.nodeContent << endl;
    }

    //call this function recursively for each of the children of the current node
    for (auto child : current->child_nodes) {
        printPreOrderTree(child, newFile, level + 1);
    }
}

void typeOfnode(Node<treeInfo>* currentNode , vector<treeInfo>& internal, vector<treeInfo>& external) {
    //base case: if the current node is null, return without processing it
    if (currentNode == nullptr) {
        return;
    }

    //checking whether the current node is an internal or external node then adds it to its respective vector
    if (currentNode->child_nodes.empty()) {
        //if the current node has no children, then it is is external and a leaf node 
        external.push_back(currentNode->node_data); 
    }
    else {
        //if the current node has any children, then it is an internal node
        internal.push_back(currentNode->node_data);
    }

    //process recursively each of the left and right subtrees in a preorder traversal
    for (auto childNode : currentNode->child_nodes) {
        typeOfnode(childNode, internal, external);
    }
}

int treeHeight(const vector<treeInfo>& data) {
    auto max_level_iter = max_element(data.begin(), data.end(), 
        [](const treeInfo& a, const treeInfo& b) { return a.nodeLevel < b.nodeLevel; });
    if (max_level_iter == data.end()) {
        return 0; //empty the node_data vector and set height to zero
    }
    return max_level_iter->nodeLevel;
}

bool isBinary(Node<treeInfo>* root) {
    //base case: if the root node is null, return true
    if (root == nullptr) {
        return true;
    }
    
    //if the root node has more than 2 children, return false (it is not a binary tree)
    if (root->child_nodes.size() > 2) {
        return false;
    }
    
    //call isBinaryTree recursively for each of the children
    for (auto child : root->child_nodes) {
        if (!isBinary(child)) {
            return false; //check if any child is not a binary tree, then return false
        }
    }
    
    //if the program reaches this statement, then the tree is a binary tree
    return true;
}


// void binaryProperties(Node<treeInfo>* root) {
//     vector<Node<treeInfo>*> q;             //initialize an empty vector to store the nodes in breadth-first order
//     q.push_back(root);                     //add the root node to the vector
    
//     bool proper = true, perfect = true, balanced = true;
//     int height = -1, prev_level = -1, node_count = 0, expected_count = 1;

//     while (!q.empty()) {                   //while the vector is not empty, keep processing nodes
//         Node<treeInfo>* curr = q.back();    //get the last element of the vector (equivalent to front of queue)
//         q.pop_back();                       //remove the last element of the vector (equivalent to dequeue)

//         if (prev_level != curr->node_data.nodeLevel) {
//             if (prev_level != -1 && node_count != expected_count) {
//                 proper = false;
//             }
//             if (height == -1) {
//                 height = prev_level;
//             }
//             else if (prev_level != height) {
//                 perfect = false;
//             }
//             expected_count *= 2;
//             node_count = 0;
//             prev_level = curr->node_data.nodeLevel;
//         }
//         node_count++;
        
//         if (!curr->child_nodes.empty()) {
//             if (curr->child_nodes.size() == 1) {
//                 balanced = false;
//             }
//             for (auto child : curr->child_nodes) {
//                 q.insert(q.begin(), child);   //add the child node to the beginning of the vector (equivalent to enqueue)
//             }
//         }
//     }

//     if (prev_level != -1 && node_count != expected_count) {
//         proper = false;
//     }
//     if (height == -1) {
//         height = prev_level;
//     }
//     else if (prev_level != height) {
//         perfect = false;
//     }

//     cout << "Proper Binary Tree: " << (proper ? "Yes" : "No") << endl;
//     cout << "Perfect Binary Tree: " << (perfect ? "Yes" : "No") << endl;
//     cout << "Balanced Binary Tree: " << (balanced ? "Yes" : "No") << endl;
// }

template <typename T>
bool binaryProperties(Node<T>* root) {
    vector<Node<T>*> current_level, next_level;
    current_level.push_back(root);

    int height = 0;
    int node_count = 0;
    bool is_balanced = true;

    while (!current_level.empty()) {
        Node<T>* current_node = current_level.back();
        current_level.pop_back();
        node_count++;

        if (current_node->child_nodes.size() > 2) {
            return false;
        }

        for (Node<T>* child : current_node->child_nodes) {
            next_level.push_back(child);
        }

        if (current_level.empty()) {
            height++;
            if (!next_level.empty() && next_level.size() != pow(2, height)) {
                is_balanced = false;
            }
            current_level = next_level;
            next_level.clear();
        }
    }

    return node_count == pow(2, height) - 1 && is_balanced;
}



void printContent(Node<treeInfo>* current , int numOfNodes) {    //define function with a TreeNode pointer parameter and an integer parameter
    if (numOfNodes == 1) {                                          //if the numOfNodes is  1
        cout << "Node's content: " << current->node_data.nodeContent << endl;    //print the content of the node pointed to by current
        cout << "Ancestor: " << "It is the Root Node, thus it does not have an ancestor." << endl;    //the node has no ancestor because it's the root node
        cout << "Descendant: " << (current->child_nodes.size() ? current->child_nodes[0]->node_data.nodeContent : "Does not have any descendants.") << endl;   //display the content of the first child of the node pointed to by current if it exists; if it does not exist, display a statement that says the node has no descendants
        cout << "Sibling: " << "It is the Root Node, thus it does not have siblings." << endl;    //as it is the root node, it does not have any siblings
        return;    //exit the function
    }

    auto childIterator = current->child_nodes.begin();
    while (childIterator != current->child_nodes.end()) {    //iterate through the nodes's children pointed to by current
        auto currentChild = *childIterator;
        if (currentChild->node_data.nodeIndex == numOfNodes) {    //if the numOfNodes is equivalent to the node number of the child
            cout << "Node's content: " << currentChild->node_data.nodeContent << endl;    //display the contents of the child node
            cout << "Ancestor: " << current->node_data.nodeContent << endl;    //display the contents of the parent node
            cout << "Descendant: " << (currentChild->child_nodes.size() ? currentChild->child_nodes[0]->node_data.nodeContent : "Does not have any descendants.") << endl;    //display the contents of the child node's first child if it exists. if it does not, print that the child node has no descendants
    
            bool hasSibling = false;    //declare & initialize a boolean variable to check if the child has siblings
            Node<treeInfo>* sibling = nullptr;    // Declare and initialize a pointer variable to point to the sibling of the child node
            auto siblingIterator = current->child_nodes.begin();
            while (siblingIterator != current->child_nodes.end()) {    // Iterate through the children of the parent node
                if ((*siblingIterator)->node_data.nodeIndex != numOfNodes) {    // If the node_num does not match with the node number of the child
                    hasSibling = true;    // Set the sibling_present variable to true
                    sibling = *siblingIterator;    // Point the sibling pointer variable to the current child node
                    break;    // Exit the loop
                }
                siblingIterator++;
            }
    
            cout << "Sibling: " << (hasSibling ? sibling->node_data.nodeContent : "Does not have any siblings.") << endl;    // Print the content of the sibling of the child node if it exists, else print that the child node has no sibling
        }
        else {
            printContent(currentChild, numOfNodes);    // Recursively call the function for the child node
        }
        childIterator++;
    }
}




void buildTreefromFile(vector<treeInfo>& node_data) {
    string filename;

    // Prompt user to enter filename and store it in the 'filename' variable
    cout << "Enter filename: ";
    cin >> filename;

    // Open the file with the name entered by the user
    ifstream file(filename);

    // Check if the file was successfully opened
    if (!file.is_open()) {
        cout << "Error opening file" << endl;
        return;
    }

    // Declare variables to store values from each line of the file
    string line;
    int level, node_num;
    string edge, content;

    // Initialize a counter for the number of lines read
    int n = 0;

    // Read each line from the file and parse the data
    for (string line; getline(file, line); ) {
    // Stop reading
    if (line == "") break;

    // Use istringstream to read the line and parse the data
    istringstream iss(line);

    // Parse the first line differently
    if (n == 0 && !(iss >> level >> node_num)) {
        cout << "Error processing input" << endl;
        break;
    }
    // Parse all subsequent lines with an extra 'edge' variable
    else if (n != 0 && !(iss >> level >> node_num >> edge)) {
        cout << "Error analyzing input" << endl;
        break;
    }

    // Increment the line counter
    n++;

    // read the rest of the line into the content variable
    getline(iss, content);

    // Remove tab spaces from the input string
    content.erase(remove(content.begin(), content.end(), '\t'), content.end());

    // Store the parsed data in a Data struct and add it to the vector of nodes
    node_data.push_back({ level, node_num, edge, content });
}


    // Close the file
    file.close();
}

// Comparator function to sort treeInfo objects in ascending order of nodeIndex
bool sortByNodeInfo(const treeInfo& n1, const treeInfo& n2) {
    return n1.nodeIndex < n2.nodeIndex;
}


// Recursive function to build a tree from a vector of nodes
void buildTreeFromNodes(Node<treeInfo>* currentNode, vector<treeInfo>& nodes, int& nodeIndex) {
    for (; nodeIndex < nodes.size() && nodes[nodeIndex].nodeLevel > currentNode->node_data.nodeLevel; nodeIndex++) {
        // If there are multiple levels between the current node and the next node, recursively build children for the last child
        if (nodes[nodeIndex].nodeLevel - currentNode->node_data.nodeLevel > 1) {
            buildTreeFromNodes(currentNode->child_nodes.back(), nodes, nodeIndex);
        }

        //check if end of vector is reached
        if (nodeIndex >= nodes.size()) return;

        // Create a new node with the data from the current node and add it as a child to the current node
        Node<treeInfo>* new_node = new Node<treeInfo>({ nodes[nodeIndex].nodeLevel, nodes[nodeIndex].nodeIndex, nodes[nodeIndex].nodeEdge, nodes[nodeIndex].nodeContent });
        currentNode->child_nodes.push_back(new_node);
    }
}



int main() {
    vector<treeInfo> data;
  
    // Read data from file and store in vector
    buildTreefromFile(data);

    // Check if the vector is empty, terminate program if there are no nodes
    if (!data.size()) {
        cout << "File has no nodes; exiting program." << endl;
    }

    // Sort the vector by node number
    int index = 1;
    sort(data.begin(), data.end(), sortByNodeInfo);

    // Create the root of the decision tree
    Node<treeInfo> root({ data[0].nodeLevel, data[0].nodeIndex, data[0].nodeEdge, data[0].nodeContent });

    // Build the decision tree starting from the root
    buildTreeFromNodes(&root, data, index);

    //create the new file for the output
    ofstream newfile; // Declare an output file stream object
    newfile.open("about_tree.txt"); // Associate the output stream with a new file

    // Print the decision tree

    printPreOrderTree(&root, newfile);
    newfile << endl;

    // Print tree properties
    newfile << "-------------------\nTree Properties\n-------------------" << endl;
    newfile << "\n";

    // Categorize nodes into internal and external nodes
    vector<treeInfo> internal_nodes;
    vector<treeInfo> external_nodes;
    typeOfnode(&root, internal_nodes, external_nodes);

    // Print root node, number of internal nodes, number of external nodes and the height of the tree
    newfile << "Root: " << root.node_data.nodeContent << endl;
    newfile << "Number of internal nodes: " << internal_nodes.size() << endl;
    newfile << "Number of external nodes: " << external_nodes.size() << endl;
    newfile << "Tree Height: " << treeHeight(data) << endl;
    newfile << endl;

    // Print the content of all internal nodes
    newfile << "Internal Nodes:" << endl;
    for (auto node : internal_nodes) {
        newfile << node.nodeContent << endl;
    }

    newfile << "\n";

    // Print the content of all external nodes
    newfile << "External Nodes:" << endl;
    for (auto node : external_nodes) {
        newfile << node.nodeContent << endl;
    }



    newfile << endl;
    // Print section title
    newfile << "-------------------\nBinary Tree Properties\n-------------------" << endl;
    newfile << endl;
    // Print whether the tree is binary or not
    if (isBinary(&root)) {
      newfile << "Binary Tree: Yes" << endl;
      Node<treeInfo>* root = new Node<treeInfo>(treeInfo(0, 0, "", ""));
      bool is_proper = binaryProperties(root);
    }
    else {
        newfile << "Binary Tree: No" << endl;
    }

  



    // Print section title
    cout << endl;
    cout << "-------------------\nExplore the Tree\n-------------------" << endl;
    cout << endl;



    // Initialize command variable
    string command = "";


    // Loop to explore the tree
    while (true) {
        // Prompt user for node to explore
        cout << "Which node would you like to explore (enter a position as a number or \"exit\" to exit the program): ";
        // Read user input into command variable
        cin >> command;
        cout << endl;

        // If command is "exit", terminate the program
        if (command == "exit") {
            cout << "Goodbye!" << endl;
            break;
        }
        // If command is invalid, prompt user to try again
        else if (stoi(command) > data.size()) {
            cout << "Invalid input. Please try again!" << endl;
            continue;
        }

        // Print information about the specified node
        printContent(&root, stoi(command));
        cout << endl;
    }


    return 0;
}