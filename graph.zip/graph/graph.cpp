/*********************************************************************************************
 * COP 4530
 * Fatemah Elsewaky
 * Noreen Abdelmaksoud
 * April 21, 2023
 * 
 * This file contains the code for the implementation of the ADT of a graph
 * that utilizes functions of undirected graphs. Furthermore, this program
 * makes use of reading information from a text file, classes,
 * and constrcutors.
 * *******************************************************************************************/
#include <iostream>
#include <vector>
#include <string>
#include <sstream>
#include <fstream>
#include <set>
#include <algorithm>
#include <limits>

using namespace std;

//function that eliminates any whitespace characters located at the beginning or end of a string
string remove_whitespace(const string& input) {
    size_t start = 0, end = input.length() - 1;

    while (start <= end && isspace(input[start])) {
        ++start;
    }
  
    while (end >= start && isspace(input[end])) {
        --end;
    }
  
    return input.substr(start, end - start + 1);
}

//a class designed to store information about a graph and offer various functions related to graphs
class graph {
public:
    //constructor
    graph(const string& filename) {
      //open the input file for reading
      ifstream in_File(filename);
      //initialize a string to hold the current line being read from the file
      string row;
      //check if the file was successfully opened
      if (in_File.is_open()) {
        //read the first line, which contains the vertex labels
        if (getline(in_File, row)) {
          //create an input string stream to parse the line
          istringstream V_Stream(row);
          string VLabel;
          //read each vertex label separated by commas
          for (string VLabel; getline(V_Stream, VLabel, ',');) {
            //create a new vertex object and add it to the graph's vertex list
            vertex* v = new vertex(remove_whitespace(VLabel), *this);
            vertex_list.push_back(v);
          }
        }
    
        //read the remaining lines, which contain the edges
        for (string row; getline(in_File, row);) {
          //create an input string stream to parse the edge data
          istringstream E_Stream(row);
          string sourceVertexLabel, destVertexLabel, edgeLabel;
          //read the source vertex label, destination vertex label, and edge label separated by tabs
          getline(E_Stream, sourceVertexLabel, '\t');
          getline(E_Stream, destVertexLabel, '\t');
          getline(E_Stream, edgeLabel);
          //find the vertex objects corresponding to the source and destination labels
          vertex* sourceVertex = find_V(remove_whitespace(sourceVertexLabel));
          vertex* destVertex = find_V(remove_whitespace(destVertexLabel));
          //if both vertices exist, create a new edge object and add it to the graph's edge list
          if (sourceVertex && destVertex) {
            edge* e = new edge(sourceVertex, destVertex, edgeLabel, *this);
            edge_list.push_back(e);
          }
        }
        // close the input file
        in_File.close();
      }
    }

    class edge;
    class vertex;
    
    vector<edge*> edge_list; //pointer to store objects of edge
    vector<vertex*> vertex_list; //pointer to store objects of vertex

    class edge { //edge class that stores information of edge
    public:
        vertex* Ver1; //vertex number 1 of the edge
        vertex* Ver2; //vertex number 2 of the edge
        string Elabel; //label for edge
        graph& Egraph; //reference to the edge of the graph

        edge(vertex* Ver1, vertex* Ver2, const string& Elabel, graph& Egraph) : Ver1(Ver1), Ver2(Ver2), Elabel(Elabel), Egraph(Egraph) {}

        //overload the dereference operator so that it returns the edge's label
        string operator*() {
            return Elabel;
        }

        //function that returns the pair of end vertex_list of the edge
        pair<vertex*, vertex*> endVertices() {
            return make_pair(Ver1, Ver2);
        }

        //function that returns the opposite vertex of the edge's given vertex
        vertex* opposite(vertex* V) {
            if (Ver1 == V) {
                return Ver2;
            } else {
                return Ver1;
            }
        }


        //function that checks if the edge is adjacent to another edge
        bool isAdjacentTo(edge* f) {
            return (f->Ver1 == Ver1 || f->Ver2 == Ver1 || f->Ver1 == Ver2 || f->Ver2 == Ver2);
        }

        //function that checks if the edge is incident on a vertex
        bool isIncidentOn(vertex* V) {
            // Iterate through the list of edges in the graph
            for (auto it = Egraph.edge_list.begin(); it != Egraph.edge_list.end(); ++it) {
                // Check if the current edge is incident on the given vertex
                if ((*it)->Ver1 == V || (*it)->Ver2 == V) {
                    // If the edge is incident on the vertex, return true
                    return true;
                }
            }
            // If no incident edge was found, return false
            return false;
        }

    };
    /////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

    class vertex { //vertex class that stores information of vertex
    public:
        
        string Vlabel; //label for vertex
        graph& Vgraph; //reference to vertex of the graph

        vertex(const string& Vlabel, graph& Vgraph) : Vlabel(Vlabel), Vgraph(Vgraph) {}

        //overload the dereference operator so that it returns the label of the vertex
        string operator*() {
            return Vlabel;
        }
    
        vector<edge*> incidentEdges() {
            vector<edge*> edge_ptrs; //initializes a vector that stores incident edges
            //loops over every edge in the graph
            for (edge* e : Vgraph.edge_list) {
                bool isIncident = (e->Ver1->Vlabel == Vlabel) || (e->Ver2->Vlabel == Vlabel); //checks if the edge is incident on the current vertex
                if (isIncident) { //if the edge is incident, it gets added to the edge_ptrs vector
                    edge_ptrs.push_back(e);
                }
            }

            return edge_ptrs; //return the vector of incident edges
        }

        //function that checks if the current vertex is adjacent to the given vertex
      bool isAdjacentTo(vertex* Ver) {
          //gets an iterator that points to the first element in the edge list of the current vertex
          auto it = Vgraph.edge_list.begin();
          //loops through the edge list using an iterator
          while (it != Vgraph.edge_list.end()) {
              //checks if the current edge connects the given vertex & the current vertex
              if ((*it)->Ver1 == Ver && (*it)->Ver2 == this) {
                  //if the edge connects the vertices, return true
                  return true;
              }
              //checks if the current edge connects the given vertex and the current vertex (in reverse order)
              else if ((*it)->Ver2 == Ver && (*it)->Ver1 == this) {
                  //if the edge connects the vertices, return true
                  return true;
              }
              //increment the iterator to move it to the next element in the edge list
              ++it;
          }
          //if no adjacent edge was found, return false
          return false;
      }

    };
    /////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
    
    //FUNCTIONS INSIDE THE GRAPH
    vector<vertex*> vertices(){
      return vertex_list;
    }

    vector<edge*> edges(){
      return edge_list;
    }
    void insertVertex(string s){
      vertex* v = new vertex(s, *this);
      vertex_list.push_back(v);
    }

     //function to insert an edge between two vertexList with given labels
    void insertEdge(const string& Ver1Label, const string& Ver2Label, const string& label) {
      //find the vertices with the given labels
      vertex* Ver1 = find_V(Ver1Label);
      vertex* Ver2 = find_V(Ver2Label);

      //check if both vertices exist
      if (!(Ver1 && Ver2)) {
        cout << "Failed to insert edge: One or both vertices do not exist" << endl;
        return;
      }
    
      //check if the edge already exists between the given vertices
      bool edge_exists = false;
      int i = 0;
      while (!edge_exists && i < edge_list.size()) {
        edge* e = edge_list[i];
        if ((e->Ver1->Vlabel == Ver1->Vlabel && e->Ver2->Vlabel == Ver2->Vlabel) ||
          (e->Ver1->Vlabel == Ver2->Vlabel && e->Ver2->Vlabel == Ver1->Vlabel)) {
          cout << "Failed to insert edge: Edge already exists" << endl;
          edge_exists = true;
        }
        i++;
      }
      if (edge_exists) {
        return;
      }
    
    //create and insert the new edge
    edge* e = new edge(Ver1, Ver2, label, *this);
    edge_list.push_back(e);
    cout << "Edge inserted successfully" << endl;
}


    //function to erase a vertex that has specific label
    void eraseVertex(const string& label) {
      vertex* v = find_V(label);
    
      //check if vertex exists
      if (!v) {
        cout << "Failed to remove vertex: no vertex found with the given label." << endl;
        return;
      }
    
      //remove every incident edge that belongs to the vertex
      bool edge_deleted = true;
      while (edge_deleted) {
        edge_deleted = false;
        int i = 0;
        while (i < edge_list.size()) {
          edge* e = edge_list[i];
          if (e->Ver1 == v || e->Ver2 == v) {
            delete e;
            edge_list.erase(edge_list.begin() + i);
            edge_deleted = true;
          }
          else {
            i++;
          }
        }
      }
      
      //remove the vertex
      bool vertex_deleted = false;
      int j = 0;
      while (j < vertex_list.size()) {
        vertex* vertex = vertex_list[j];
        if (vertex == v) {
          delete vertex;
          vertex_list.erase(vertex_list.begin() + j);
          vertex_deleted = true;
        }
        else {
          j++;
        }
      }  
    
      if (vertex_deleted) {
        cout << "Vertex removed successfully." << endl;
      }
      else {
        cout << "Failed to remove vertex: the vertex was not found in the graph." << endl;
      }
    }


    //function to erase an edge at a given position in the edge list
    void EraseEdge(int position){
      //get an iterator pointing to the start of the edge list
      vector<edge*>::iterator i = edge_list.begin();
      //move the iterator to the desired position & erase the edge
      edge_list.erase(i + position);
    }

    //function that uses a vertex's label to find it in the graph 
    vertex* find_V(string label) {
        int i = 0;
        while (i < vertex_list.size()) {
          vertex* Vertex = vertex_list[i];
          if (Vertex->Vlabel == label) {
            return Vertex;
          }
          i++;
        }
        return nullptr;
    }


    //function that finds every path between two vertices in the graph
    vector<vector<vertex*>> GraphPath(vertex* ver1, vertex* ver2) {
        vector<vertex*> p; //the path currently being traversed
        vector<vector<vertex*>> p2; //maintain a record of all discovered paths

        //perform depth-first search to find all paths between the two vertices
        depth_first_search(ver1, ver2, p, p2); 

        return p2;
    }

    // A set to store visited vertices during Depth-First Search (DFS)
    set<vertex*> Set; 

    // A recursive function to explore the graph and find all paths from the source vertex to the destination vertex

    void depth_first_search(vertex* ver1, vertex* ver2, vector<vertex*>& p, vector<vector<vertex*>>& p2) {
        // If the vertex has already been visited, return
        if (Set.find(ver1) != Set.end()) return;
        // Mark the current vertex as visited
        Set.insert(ver1);

        // Add the current vertex to the current path
        p.push_back(ver1);

        // If the destination vertex is reached, add the current path to the vector of all paths

        if (ver1 == ver2) {
            p2.push_back(p);
        }
        // if not, explore the adjacent vertices recursively
        else {
            auto edge = edge_list.begin();
            while (edge != edge_list.end()) {
                if ((*edge)->Ver1 == ver1 || (*edge)->Ver2 == ver1) {
                    depth_first_search((*edge)->opposite(ver1), ver2, p, p2);
                }
                ++edge;
            }
        }

        // Backtrack: remove the current vertex from the current path and unmark as visited
        p.pop_back();
        Set.erase(ver1);
    }
};

int main() {
  
  string filename;
  cout << "\nHello!\n" << endl;
  while (true) {
    cout << "Enter a file name: ";
    cin >> filename;
    //open the input file for reading
    ifstream inputFile(filename);
    inputFile.open(filename);
    if (inputFile.is_open()) {
      cout << "\nFile opened successfully.\n\n";
      break;
    }
    cout << "Error opening file. Please try again.\n";
  }
  

  graph G(filename); //creates a graph from the file that is entered by the user
  cout << "Thank you. Your graph is ready." << endl;

  //while loop that regulates the main componenets of this program

  while (true) {
    cout << "------------------------" << endl
         << "What would you like to do?" << endl
         << "------------------------" << endl
         << "1. Find edges incident on a vertex" << endl
         << "2. Find a path in the graph" << endl
         << "3. Insert an edge" << endl
         << "4. Erase a vertex" << endl
         << "5. Quit the program" << endl
         << "Enter your choice: ";
    
    string choice;
    bool valid_input = false;
    while(!valid_input){
      cin >> choice;
      if (choice == "1" || choice == "2" || choice == "3" || choice == "4" || choice == "5") {
        valid_input = true;
      }
      else{
        cout << "Invalid choice. Please enter a number in the range of 1 to 5: ";
      }
    }
    int continue_choice = stoi(choice);
    
    cout << "****************************************" << endl;

     switch (continue_choice) { //switch cases for the different choices that are given to the user
       
      case 1: { //choice 1: find edges incident on a vertex
        cin.ignore(numeric_limits<streamsize>::max(), '\n');
        string vertex_label;
        cout << "Enter the label of the vertex: ";
        getline(cin, vertex_label);
        graph::vertex* vertex = G.find_V(remove_whitespace(vertex_label));
        if (vertex) {
          vector<graph::edge*> result = vertex->incidentEdges();
          auto edge = result.begin(); //get the beginning iterator of result container
          while (edge != result.end()) { // while edge has not reached the end of container
            cout << vertex->Vlabel << " to " << (*edge)->opposite(vertex)->Vlabel << " is " << (*edge)->Elabel << endl; // print the vertex label, opposite vertex label and edge label
            ++edge; // move to the next edge in the container
          }
        }
        else {
          cout << "Vertex not found." << endl;
        }
        break;
        }
       
      case 2: { //choice 2: find a path in the graph
        cin.ignore(numeric_limits<streamsize>::max(), '\n');
        string L1, L2;
        cout << "Enter the label of the first vertex: ";
        getline(cin, L1);
        cout << "Enter the label of the second vertex: ";
        getline(cin, L2);

        graph::vertex* v1 = G.find_V(remove_whitespace(L1));
        graph::vertex* v2 = G.find_V(remove_whitespace(L2));
        if (v1 == nullptr || v2 == nullptr) {
          cout << "Error: One or both vertices not found." << endl;
          continue;
        }

        //finds all paths between the 2 vertices
        vector<vector<graph::vertex*>> paths = G.GraphPath(v1, v2);

        //prints paths with at least 3 vertices
        bool noPaths = true; // initialize noPaths flag to true
        auto path = paths.begin(); // get the beginning iterator of paths container

        while (path != paths.end()) { // while path has not reached the end of container
          if (path->size() > 2) { // check if the path size is greater than 2
            noPaths = false; // set noPaths flag to false
            int i = 0;
            while (i < path->size()) { // loop through path nodes
              cout << (*path)[i]->Vlabel; // print the node label
              if (i != path->size() - 1) { // if not the last node in path
                cout << " to ";
              }
              else { // if the last node in path
              cout << endl;
            }
            ++i; // move to the next node in the path
          }
        }
        ++path; // move to the next path in the container
      }

      // check if no paths with size greater than 2 were found
      if (noPaths) {
        cout << "No path with at least three vertexList found." << endl;
      }
      break;
    }

      case 3: { //choice 3: insert an edge
        cin.ignore(numeric_limits<streamsize>::max(), '\n');
        string Ver1, Ver2, EdgeLabel;
        cout << "Enter the label of the first vertex: ";
        getline(cin, Ver1);
        cout << "Enter the label of the second vertex: ";
        getline(cin, Ver2);
        cout << "Enter the label for the edge: ";
        getline(cin, EdgeLabel);
        G.insertEdge(remove_whitespace(Ver1), remove_whitespace(Ver2), remove_whitespace(EdgeLabel));
        break;
      }
       
      case 4: { //choice 4: erase a vertex
        cin.ignore(numeric_limits<streamsize>::max(), '\n');
        string VertexLabel;
        cout << "Enter the label of the vertex to erase: ";
        getline(cin, VertexLabel);
        G.eraseVertex(remove_whitespace(VertexLabel));
        break;
      }
      case 5: { //choice 5: quit the program
        cout << "Thank you for using our program! Have a great day! :)\n";
        return 0;
      }
      default: { //default case for input validation
        cout << "Invalid option." << endl;
        break;
      }
    }
    
    cout << "****************************************" << endl;

  }
  
  return 0;
}